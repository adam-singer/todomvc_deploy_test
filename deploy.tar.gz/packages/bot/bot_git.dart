library bot_git;

import 'dart:async';
import 'dart:io';
import 'package:bot/bot.dart';
import 'package:bot/bot_io.dart';

part 'src/bot_git/git.dart';
part 'src/bot_git/git_dir.dart';
