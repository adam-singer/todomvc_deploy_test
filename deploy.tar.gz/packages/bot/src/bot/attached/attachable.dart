part of bot;

class Attachable {
  final String name;

  Attachable(this.name);
}
