part of bot_retained;

class _RetainedEnum {
  final String name;

  const _RetainedEnum(this.name);

  String toString() => name;
}
